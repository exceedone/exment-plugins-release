<?php

namespace App\Plugins\ExmentGroupware;

/**
 * Exment's Feature management (Admin setting → Feature management), in the
 * versions of Exment that have it: a feature is off until a system
 * administrator turns it on, and they choose the role groups that may use it.
 *
 * - The web mail is a feature of this plugin (MAIL, registered when the
 *   plugin is made).
 * - The Office part opens the files of the file server, a feature of Exment
 *   itself (FILE_SERVER): it follows it.
 *
 * Exment turns away the pages of a feature not used (404) and hides their
 * menus. The plugin checks too (allowed()), for the versions of Exment that
 * check before the plugin has registered its feature (the routes that skip
 * admin.bootstrap). On an Exment without Feature management everything is
 * used, as before.
 */
class FeatureGate
{
    const MAIL = 'exment_groupware.mail';
    const OFFICE = 'exment_groupware.office';
    const CALENDAR = 'exment_groupware.calendar';
    /** Outside calendars and the ICS export of the calendar (ISS02947 part 5): off at first, with the calendar. */
    const CALENDAR_LINKS = 'exment_groupware.calendar_links';
    /** The chat (ISS02945): new, off at first. */
    const CHAT = 'exment_groupware.chat';
    /** Calls from a chat room (ISS02946): new, off at first, with the chat. */
    const CALL = 'exment_groupware.call';
    const FILE_SERVER = 'file_server';

    // a string, not ::class: an Exment without Feature management does not have the class
    protected const FEATURES = 'Exceedone\Exment\Services\Features';

    /** Whether Exment has Feature management. */
    public static function available(): bool
    {
        return class_exists(static::FEATURES);
    }

    /** Whether the site uses the feature at all (a batch has no login user; true without Feature management). */
    public static function allowedOnSite(string $key): bool
    {
        if (!static::available()) {
            return true;
        }
        return boolval(call_user_func([static::FEATURES, 'enabled'], $key));
    }

    /** Whether the login user may use the feature (true without Feature management). */
    public static function allowed(string $key): bool
    {
        if (!static::available()) {
            return true;
        }
        return boolval(call_user_func([static::FEATURES, 'allowed'], $key));
    }

    /**
     * The answer when the login user may not use the feature, or null when
     * they may: Exment's own answer (Features::deny: 404 when it is not used,
     * with the link to Feature management for a system administrator, 403
     * when the user may not use it, JSON for ajax). It is returned, not
     * thrown: Exment shows an exception of an admin page as its error page.
     * abort(404) when Exment does not have Features::deny.
     *
     * @return \Symfony\Component\HttpFoundation\Response|null
     */
    public static function deny(string $key)
    {
        if (static::allowed($key)) {
            return null;
        }
        if (method_exists(static::FEATURES, 'deny')) {
            return call_user_func([static::FEATURES, 'deny'], $key);
        }
        abort(404);
    }

    /**
     * The web mail: its pages (and the API of the mail program, which are web
     * routes under them) are plugins/<uri>/mail.
     *
     * @param \Exceedone\Exment\Model\Plugin $plugin
     */
    public static function registerMail($plugin): void
    {
        if (!static::available()) {
            return;
        }
        call_user_func([static::FEATURES, 'register'], static::MAIL, [
            'label' => static::text('feature_mail', 'メール'),
            'description' => static::text('feature_mail_help', 'ブラウザーで、今お使いのメール（Xserver・KAGOYA・Microsoft 365・Gmail・そのほかの IMAP / SMTP のサーバー）を読む・書く・送る（Exment Plugin Groupware）。'),
            'endpoints' => [$plugin->getRouteUri('mail')],
            'plugin' => $plugin->plugin_name,
            // the plugin had the mail before Feature management: it stays on in the sites
            // that had the plugin then (a new site starts with it off)
            'existing' => true,
        ]);
    }

    /**
     * Office (ISS02827): a row of its own in Feature management. While ibisOffice is
     * not there, the row says what it needs and gives the button to install it (an
     * Exment whose Feature management has no buttons shows the words only). Its pages
     * stop when it is turned off. It stays on in the sites that had the plugin before.
     */
    public static function registerOffice($plugin): void
    {
        if (!static::available()) {
            return;
        }
        $office = new IbisOffice($plugin);
        $missing = !$office->isAvailable() && $office->customUrl() === null;
        $update = $office->customUrl() === null && $office->updateAvailable();
        $description = 'ブラウザーで Word・Excel・PowerPoint を開く・編集する（ファイル共有とデータの添付。Exment Plugin Groupware の ibisOffice）。';
        if (!$missing) {
            if ($office->customUrl() !== null) {
                $description .= ' ほかの場所の ibisOffice を使います。';
            } elseif ($update) {
                $description .= ' ibisOffice ' . $office->activeVersion() . ' がこのサイトに入っています。新しい版 ' . IbisOffice::VERSION . ' があります（更新するまでは、今の版で開きます）。';
            } else {
                $description .= ' ibisOffice ' . IbisOffice::VERSION . ' がこのサイトに入っています。';
            }
        } else {
            $description .= ' ibisOffice がまだ入っていません。入れるには、PHP の zip の拡張と、サイトの public/ に約 125MB の空きが要ります（LibreOffice は要りません）。';
            $problems = $office->problems();
            if (!empty($problems)) {
                $description .= ' 今は入れられません: ' . implode(' ', $problems);
            }
        }
        $definition = [
            'label' => static::text('feature_office', 'Office（ibisOffice）'),
            'description' => $description,
            'endpoints' => [$plugin->getRouteUri('office'), $plugin->getRouteUri('view'), $plugin->getRouteUri('edit'), $plugin->getRouteUri('blank')],
            'plugin' => $plugin->plugin_name,
            'existing' => true,
            'manual' => 'plugin_groupware?id=office',
        ];
        if ($missing) {
            $definition['action'] = ['label' => 'ibisOffice を入れる', 'url' => $plugin->getFullUrl()];
        } elseif ($update) {
            $definition['action'] = ['label' => 'ibisOffice を ' . IbisOffice::VERSION . ' に更新する', 'url' => $plugin->getFullUrl()];
        }
        call_user_func([static::FEATURES, 'register'], static::OFFICE, $definition);
    }

    /** The chat (ISS02945): its page and its API are plugins/<uri>/chat. Off at first. */
    public static function registerCall($plugin): void
    {
        if (!static::available()) {
            return;
        }
        call_user_func([static::FEATURES, 'register'], static::CALL, [
            'label' => static::text('feature_call', '通話'),
            'description' => static::text('feature_call_help', 'チャットのルームから、4 人までの声・カメラ・画面の共有で通話する（ブラウザーどうしで直接つなぐ。録音はしない）。'),
            'endpoints' => [],
            'plugin' => $plugin->plugin_name,
            'requires' => static::CHAT,
            'existing' => false,
        ]);
    }

    public static function registerChat($plugin): void
    {
        if (!static::available()) {
            return;
        }
        call_user_func([static::FEATURES, 'register'], static::CHAT, [
            'label' => static::text('feature_chat', 'チャット'),
            'description' => static::text('feature_chat_help', 'グループと 1 対 1 のルームで話す。@メンション・既読の人数・ファイル（Exment Plugin Groupware）。'),
            'endpoints' => [$plugin->getRouteUri('chat')],
            'plugin' => $plugin->plugin_name,
            'existing' => false,
        ]);
    }

    /**
     * The key of a text of the plugin's language files (resources/lang):
     * Exment translates it when it shows the page, in the language of the
     * viewer. The Japanese text when Exment does not load those files.
     */
    protected static function text(string $key, string $default): string
    {
        $name = 'exment_exment_groupware::groupware.' . $key;
        if (!class_exists('Illuminate\Support\Facades\Lang')) {
            return $default;
        }
        // not before Exment has added the plugin's lang files: asked earlier, the translator
        // keeps an empty group "groupware" for the request, and every trans() of the plugin
        // gives its key back (the calendar's buttons, its 「予定あり」)
        try {
            $namespaces = app('translator')->getLoader()->namespaces();
        } catch (\Throwable $e) {
            return $default;
        }
        if (!array_key_exists('exment_exment_groupware', $namespaces)) {
            return $default;
        }
        return \Illuminate\Support\Facades\Lang::has($name) ? $name : $default;
    }

    /**
     * The calendar (ISS02947): a row of its own in Feature management, off at first (a new
     * feature of the plugin: not "existing").
     *
     * @param \Exceedone\Exment\Model\Plugin $plugin
     */
    public static function registerCalendar($plugin): void
    {
        if (!static::available()) {
            return;
        }
        call_user_func([static::FEATURES, 'register'], static::CALENDAR, [
            'label' => static::text('feature_calendar', 'カレンダー'),
            'description' => static::text('feature_calendar_help', '共有のカレンダー：自分・ほかの人・部署の予定を日・週・月・リストで見る、繰り返し、参加者と返事、公開の範囲（Exment Plugin Groupware）。'),
            'endpoints' => [$plugin->getRouteUri('cal')],
            'plugin' => $plugin->plugin_name,
        ]);
    }

    /**
     * The calendar's outside calendars (ISS02947, part 5): a person's ICS export address and
     * the ICS addresses read into their calendar. A row of its own, off at first, with the
     * calendar. Its API is under the calendar's pages (cal/api/link..., cal/api/feed...), which
     * check it themselves; the export address checks it for the person it belongs to.
     *
     * @param \Exceedone\Exment\Model\Plugin $plugin
     */
    public static function registerCalendarLinks($plugin): void
    {
        if (!static::available()) {
            return;
        }
        call_user_func([static::FEATURES, 'register'], static::CALENDAR_LINKS, [
            'label' => static::text('feature_calendar_links', 'カレンダーの連携（ICS）'),
            'description' => static::text('feature_calendar_links_help', '自分のカレンダーを ICS の URL でほかのカレンダーに見せる・ほかのカレンダー（ICS の URL）を読みこむ（Exment Plugin Groupware）。'),
            'endpoints' => [],
            'plugin' => $plugin->plugin_name,
            'requires' => static::CALENDAR,
            'existing' => false,
        ]);
    }

    /**
     * Whether a person (an Exment user id, not the login user) may use the feature: for an
     * address read without login (the calendar's ICS export). True without Feature management;
     * false when the person has no login.
     */
    public static function allowedFor(string $key, int $userId): bool
    {
        if (!static::available()) {
            return true;
        }
        if (!static::allowedOnSite($key)) {
            return false;
        }
        try {
            $login = \Exceedone\Exment\Model\LoginUser::where('base_user_id', $userId)->first();
        } catch (\Throwable $e) {
            return false;
        }
        if (!isset($login)) {
            return false;
        }
        return boolval(call_user_func([static::FEATURES, 'allowed'], $key, $login));
    }
}
